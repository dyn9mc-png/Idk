# Anubis Auto Builder — sursă addon

Addon client-side Fabric pentru Anubis Client `0.9.9.3+mc1.21.11`.

## Funcții prezente în sursă

- Modulul **Auto Builder** este în categoria **Render**.
- Încarcă scheme Sponge `.schem` și Litematica `.litematic` din `<Minecraft>/schematics/`.
- Smart Restock: calculează necesarul și încearcă să ia materialele lipsă din containere conectate.
- Smart Storage: suport pentru mai multe containere conectate.
- Smart Scaffold: folosește blocuri temporare și încearcă să le elimine după construcție.
- Human Movement: rotire graduală și mers spre poziții mai bune.
- Progress HUD: afișează în action bar progresul, blocurile rămase și câteva materiale lipsă.
- Poți conecta/deconecta un container activând `link-mode` și dând click dreapta pe el.
  Legăturile sunt salvate în directorul de config, în `schem-links.txt`.
- Poate folosi blocuri temporare de scaffolding pentru a ajunge la poziții greu accesibile
  și le poate elimina ulterior dacă `cleanup` este activat.
- Are întârzieri, pauze, mișcări ale privirii și rotire graduală variabile.

## Compilare

Necesită JDK 21 și Gradle 8.x.

1. Creează directorul `libs/`.
2. JAR-ul furnizat în conversație este deja copiat în `libs/anubisplus.jar` în acest pachet. Dacă folosești altă versiune, înlocuiește-l cu JAR-ul exact al clientului instalat.
3. Din directorul proiectului rulează `gradle build`.
4. Copiază `build/libs/anubis-schematic-addon-1.0.0.jar` în `mods/`, lângă Anubis și Fabric API.

## Folosire

1. Pune fișierul `.schem` sau `.litematic` în `<Minecraft>/schematics/`.
2. Pornește jocul și activează **Auto Builder** din categoria **Render**.
3. Setează opțiunea `file` la numele schemei.
4. Pentru restock, activează `link-mode`, dă click dreapta pe containerele de depozit
   și apoi dezactivează `link-mode`.
5. Verifică setările `scaffold-block`, `cleanup`, `walk` și `use-chests`.

## Limitări importante

- Sursa existentă marchează compatibilitatea Yarn/Minecraft ca netestată; pot fi necesare
  ajustări API la compilare.
- Nu este un JAR addon compilat și testat. Acest pachet conține proiectul-sursă.
- Înainte de utilizare, testează într-o lume de backup. Automatizarea poate fi interzisă
  pe servere multiplayer; folosește-o doar unde ai permisiune.
- Comportamentul cu uși/paturi, redstone și unele stări conectate are limitările descrise
  în comentariile din `SchematicBuilderModule.java`.

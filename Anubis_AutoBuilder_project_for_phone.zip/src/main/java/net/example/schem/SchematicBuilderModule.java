package net.example.schem;

import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.anubis.client.event.impl.TickEvent;
import net.anubis.client.module.ClientModule;
import net.anubis.client.module.ModuleCategory;
import net.anubis.client.module.setting.BooleanSetting;
import net.anubis.client.module.setting.NumberSetting;
import net.anubis.client.module.setting.StringSetting;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.block.*;
import net.minecraft.block.enums.BedPart;
import net.minecraft.block.enums.DoubleBlockHalf;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.command.argument.BlockArgumentParser;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.inventory.Inventory;
import net.minecraft.item.*;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtIo;
import net.minecraft.nbt.NbtSizeTracker;
import net.minecraft.registry.Registries;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.slot.Slot;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.state.property.Properties;
import net.minecraft.state.property.Property;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;

/**
 * Schematic builder (Sponge .schem from <gamedir>/schematics).
 *
 * - Orientation: before clicking, the block's own getPlacementState() is simulated with the camera
 *   rotation the player will really have, and only placements that produce the schematic's state
 *   (stairs facing/half, logs axis, slabs top/bottom, buttons, trapdoors...) are used.
 * - Reach: it walks to a spot that can place the block; if the block is out of reach everywhere it
 *   bridges with temporary scaffold blocks and mines them again afterwards.
 * - Materials: hotbar -> inventory (opens the inventory screen and swaps) -> linked chests
 *   (walks over, opens, shift-clicks what it needs, closes).
 * - Link chests: turn on "link-mode" and right-click containers (click again to unlink).
 *
 * UNTESTED: written without the Minecraft jars; Yarn names may need small fixes.
 * Not handled: double slabs, beds/doors upper halves are skipped (the lower half places both),
 * redstone/connection states are left to the game, shulker boxes in your inventory are not opened.
 */
public final class SchematicBuilderModule extends ClientModule {
    // ------------------------------------------------------------ settings
    private final StringSetting file = addSetting("file", new StringSetting("File (in /schematics)", "build"));
    private final StringSetting scaffoldItemSetting = addSetting("scaffold-block",
            new StringSetting("Scaffold block", "minecraft:cobblestone").itemPicker());
    private final NumberSetting reach = addSetting("reach", new NumberSetting("Reach", 4.0f, 2.0f, 4.5f).step(0.1f));
    private final NumberSetting delay = addSetting("delay", new NumberSetting("Place delay (ticks)", 4f, 1f, 20f).step(1f));
    private final NumberSetting turnSpeed = addSetting("turn-speed", new NumberSetting("Max turn (deg/tick)", 30f, 5f, 90f).step(1f));
    private final NumberSetting pauseChance = addSetting("pause-chance", new NumberSetting("Pause chance %", 5f, 0f, 30f).step(1f));
    private final NumberSetting maxScaffold = addSetting("max-scaffold", new NumberSetting("Max scaffold blocks", 24f, 4f, 128f).step(1f));
    private final BooleanSetting cleanup = addSetting("cleanup", new BooleanSetting("Remove scaffolds", true));
    private final BooleanSetting walk = addSetting("walk", new BooleanSetting("Walk to better spots", true));
    private final BooleanSetting useChests = addSetting("use-chests", new BooleanSetting("Restock from linked chests", true));
    private final BooleanSetting linkMode = addSetting("link-mode", new BooleanSetting("Link mode (right-click containers)", false));

    // ------------------------------------------------------------ state
    private enum Mode { BUILD, INV_OPEN, INV_SWAP, INV_CLOSE, CH_WALK, CH_AIM, CH_WAIT, CH_TAKE, CH_CLOSE }

    private record Target(BlockPos place, BlockPos support, Direction face, Vec3d hit,
                          BlockState state, boolean scaffold, Vec3d stand) {}

    private static final Set<String> ORIENT = Set.of("facing", "axis", "half", "hinge", "face", "rotation", "orientation", "attachment");
    private static final Item[] FALLBACK = {Items.COBBLESTONE, Items.COBBLED_DEEPSLATE, Items.DIRT, Items.NETHERRACK, Items.STONE};

    private final Random rng = new Random();
    private final Map<BlockPos, BlockState> plan = new LinkedHashMap<>();
    private final Map<BlockPos, Integer> scaffolds = new HashMap<>();
    private final Set<BlockPos> failed = new HashSet<>();
    private final Map<BlockPos, Integer> attempts = new HashMap<>();
    private final Set<Item> unavailable = new HashSet<>();
    private final Set<String> links = new LinkedHashSet<>();
    private final Set<BlockPos> triedChests = new HashSet<>();
    private final Set<BlockPos> deadChests = new HashSet<>();

    private Mode mode = Mode.BUILD;
    private Target cur;
    private int cooldown, walkTicks, modeTicks, ticks, placed, took;
    private float tempo = 1f;

    // aiming (spring-damper "hand on a mouse")
    private float vy, vp, ay, ap, stiff, damp, lastYawErr;
    private boolean inMotion, movedLast;
    private Vec3d glance;

    // input we are holding
    private boolean walkedThisTick, pressedFwd, pressedJump, pressedSneak;

    // tasks
    private int swapFrom, swapTo;
    private BlockPos chest, breakPos;
    private Vec3d chestHit, breakAim;
    private Direction chestFace;
    private Map<Item, Integer> needCache = new HashMap<>();
    private int needTick = -999;

    public SchematicBuilderModule() {
        super("auto-builder", "Auto Builder",
                "Builds a .schem like a player: orients blocks, walks, bridges, restocks from chests.",
                ModuleCategory.RENDER);
        on(TickEvent.TYPE, TickEvent.PRE, e -> tick());
        loadLinks();
        UseBlockCallback.EVENT.register((pl, world, hand, hit) -> {
            if (!world.isClient() || !linkMode.get() || hand != Hand.MAIN_HAND) return ActionResult.PASS;
            BlockPos bp = hit.getBlockPos();
            if (!(world.getBlockEntity(bp) instanceof Inventory)) return ActionResult.PASS;
            String k = world.getRegistryKey().getValue() + "|" + bp.getX() + "|" + bp.getY() + "|" + bp.getZ();
            boolean added = links.add(k);
            if (!added) links.remove(k);
            saveLinks();
            pl.sendMessage(Text.literal("[Schematic] " + (added ? "Linked" : "Unlinked") + " container (" + links.size() + " total)"), true);
            return ActionResult.SUCCESS;
        });
    }

    @Override
    protected void onEnable() {
        MinecraftClient mc = MinecraftClient.getInstance();
        plan.clear(); scaffolds.clear(); failed.clear(); attempts.clear();
        unavailable.clear(); triedChests.clear(); deadChests.clear();
        cur = null; cooldown = 0; mode = Mode.BUILD; placed = 0; took = 0; ticks = 0;
        inMotion = false; vy = vp = ay = ap = 0; glance = null;
        if (mc.player == null || mc.world == null) { requestDisable(); return; }

        BlockPos origin = mc.player.getBlockPos();
        if (mc.crosshairTarget instanceof BlockHitResult bhr && bhr.getType() == HitResult.Type.BLOCK) {
            origin = bhr.getBlockPos().offset(bhr.getSide());
        }
        if (!load(mc, origin)) { requestDisable(); return; }
        chat(mc, "Schematic loaded: " + plan.size() + " blocks, " + linkedChests(mc).size() + " linked containers");
    }

    @Override
    protected void onDisable() {
        MinecraftClient mc = MinecraftClient.getInstance();
        releaseInput(mc);
        if (mc.player != null && mode != Mode.BUILD && mc.currentScreen != null) mc.player.closeHandledScreen();
        mode = Mode.BUILD;
        cur = null;
    }

    // ------------------------------------------------------------ loading
    private boolean load(MinecraftClient mc, BlockPos origin) {
        String rawName = file.get();
        String name = rawName.endsWith(".schem") || rawName.endsWith(".litematic")
                ? rawName : rawName + ".schem";
        Path path = FabricLoader.getInstance().getGameDir().resolve("schematics").resolve(name);
        try {
            NbtCompound root = NbtIo.readCompressed(path, NbtSizeTracker.ofUnlimitedBytes());
            plan.clear();
            if (name.endsWith(".litematic")) {
                return loadLitematic(mc, root, origin);
            }
            NbtCompound s = root.contains("Schematic") ? root.getCompound("Schematic").orElseThrow() : root;
            int w = s.getShort("Width").orElse((short) 0) & 0xFFFF;
            int h = s.getShort("Height").orElse((short) 0) & 0xFFFF;
            int l = s.getShort("Length").orElse((short) 0) & 0xFFFF;

            NbtCompound pal;
            byte[] data;
            if (s.contains("Blocks")) {
                NbtCompound b = s.getCompound("Blocks").orElseThrow();
                pal = b.getCompound("Palette").orElseThrow();
                data = b.getByteArray("Data").orElseThrow();
            } else {
                pal = s.getCompound("Palette").orElseThrow();
                data = s.getByteArray("BlockData").orElseThrow();
            }

            Map<Integer, BlockState> byId = new HashMap<>();
            var blocks = mc.world.getRegistryManager().getOrThrow(RegistryKeys.BLOCK);
            for (String key : pal.getKeys()) {
                byId.put(pal.getInt(key).orElse(0), BlockArgumentParser.block(blocks, key, false).blockState());
            }

            int pos = 0;
            for (int i = 0; i < w * h * l && pos < data.length; i++) {
                int value = 0, shift = 0, b;
                do {
                    b = data[pos++];
                    value |= (b & 0x7F) << shift;
                    shift += 7;
                } while ((b & 0x80) != 0 && pos < data.length);
                BlockState st = byId.get(value);
                if (st == null || st.isAir() || st.getBlock().asItem() == Items.AIR) continue;
                if (st.contains(Properties.DOUBLE_BLOCK_HALF) && st.get(Properties.DOUBLE_BLOCK_HALF) == DoubleBlockHalf.UPPER) continue;
                if (st.contains(Properties.BED_PART) && st.get(Properties.BED_PART) == BedPart.HEAD) continue;
                plan.put(origin.add(i % w, i / (w * l), (i / w) % l), st);
            }
            return !plan.isEmpty();
        } catch (IOException | CommandSyntaxException | NoSuchElementException ex) {
            chat(mc, "Could not load " + path.getFileName() + ": " + ex.getMessage());
            return false;
        }
    }


    /**
     * Reads Litematica's region-based format. Each region stores a palette and a packed
     * long-array of palette indices. Region positions/sizes are respected, including
     * negative-size regions used to encode reversed axes.
     */
    private boolean loadLitematic(MinecraftClient mc, NbtCompound root, BlockPos origin) {
        try {
            NbtCompound regions = root.getCompound("Regions").orElseThrow();
            var registry = mc.world.getRegistryManager().getOrThrow(RegistryKeys.BLOCK);
            for (String regionName : regions.getKeys()) {
                NbtCompound region = regions.getCompound(regionName).orElseThrow();
                NbtCompound posTag = region.getCompound("Position").orElseThrow();
                NbtCompound sizeTag = region.getCompound("Size").orElseThrow();
                int rx = posTag.getInt("x").orElse(0), ry = posTag.getInt("y").orElse(0), rz = posTag.getInt("z").orElse(0);
                int sx = sizeTag.getInt("x").orElse(0), sy = sizeTag.getInt("y").orElse(0), sz = sizeTag.getInt("z").orElse(0);
                int w = Math.abs(sx), h = Math.abs(sy), l = Math.abs(sz);
                if (w == 0 || h == 0 || l == 0) continue;

                List<BlockState> palette = new ArrayList<>();
                var paletteList = region.getList("BlockStatePalette").orElseThrow();
                for (var element : paletteList) {
                    if (!(element instanceof NbtCompound entry)) { palette.add(Blocks.AIR.getDefaultState()); continue; }
                    String blockName = entry.getString("Name").orElse("minecraft:air");
                    StringBuilder stateText = new StringBuilder(blockName);
                    NbtCompound props = entry.getCompound("Properties").orElse(null);
                    if (props != null && !props.getKeys().isEmpty()) {
                        stateText.append('[');
                        boolean first = true;
                        for (String key : props.getKeys()) {
                            if (!first) stateText.append(',');
                            first = false;
                            stateText.append(key).append('=').append(props.getString(key).orElse(""));
                        }
                        stateText.append(']');
                    }
                    try { palette.add(BlockArgumentParser.block(registry, stateText.toString(), false).blockState()); }
                    catch (Exception ignored) { palette.add(Blocks.AIR.getDefaultState()); }
                }
                long[] packed = region.getLongArray("BlockStates").orElse(new long[0]);
                if (palette.isEmpty() || packed.length == 0) continue;
                int bits = Math.max(2, 32 - Integer.numberOfLeadingZeros(palette.size() - 1));
                long mask = (1L << bits) - 1L;
                int total = w * h * l;
                for (int i = 0; i < total; i++) {
                    long bitIndex = (long)i * bits;
                    int li = (int)(bitIndex >>> 6), offset = (int)(bitIndex & 63);
                    if (li >= packed.length) break;
                    long value = packed[li] >>> offset;
                    if (offset + bits > 64 && li + 1 < packed.length) value |= packed[li + 1] << (64 - offset);
                    int pi = (int)(value & mask);
                    if (pi < 0 || pi >= palette.size()) continue;
                    BlockState state = palette.get(pi);
                    if (state.isAir() || state.getBlock().asItem() == Items.AIR) continue;
                    if (state.contains(Properties.DOUBLE_BLOCK_HALF) && state.get(Properties.DOUBLE_BLOCK_HALF) == DoubleBlockHalf.UPPER) continue;
                    if (state.contains(Properties.BED_PART) && state.get(Properties.BED_PART) == BedPart.HEAD) continue;
                    int x = i % w, y = i / (w * l), z = (i / w) % l;
                    if (sx < 0) x = w - 1 - x;
                    if (sy < 0) y = h - 1 - y;
                    if (sz < 0) z = l - 1 - z;
                    plan.put(origin.add(rx + x, ry + y, rz + z), state);
                }
            }
            return !plan.isEmpty();
        } catch (Exception ex) {
            chat(mc, "Could not load .litematic: " + ex.getMessage());
            return false;
        }
    }

    // ------------------------------------------------------------ links
    private Path linkFile() { return FabricLoader.getInstance().getConfigDir().resolve("schem-links.txt"); }

    private void loadLinks() {
        try { if (Files.exists(linkFile())) links.addAll(Files.readAllLines(linkFile())); } catch (IOException ignored) {}
    }

    private void saveLinks() {
        try { Files.write(linkFile(), links); } catch (IOException ignored) {}
    }

    private List<BlockPos> linkedChests(MinecraftClient mc) {
        List<BlockPos> out = new ArrayList<>();
        if (mc.world == null) return out;
        String dim = mc.world.getRegistryKey().getValue().toString();
        for (String k : links) {
            String[] a = k.split("\\|");
            if (a.length == 4 && a[0].equals(dim)) {
                out.add(new BlockPos(Integer.parseInt(a[1]), Integer.parseInt(a[2]), Integer.parseInt(a[3])));
            }
        }
        return out;
    }

    // ------------------------------------------------------------ tick
    private void tick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null || mc.interactionManager == null || plan.isEmpty()) return;
        ticks++;
        walkedThisTick = false;
        if (ticks % 20 == 0) showProgress(mc);
        run(mc);
        if (!walkedThisTick) releaseWalk(mc);
    }

    private void run(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (cooldown > 0) {
            cooldown--;
            if (mode == Mode.BUILD && mc.currentScreen == null) {
                if (glance != null) turnToward(mc, glance); else drift(mc);
            }
            return;
        }
        glance = null;
        switch (mode) {
            case BUILD -> build(mc);
            case INV_OPEN -> {
                mc.setScreen(new InventoryScreen(p));
                mode = Mode.INV_SWAP;
                cooldown = 5 + rng.nextInt(9); // eyes find the item
            }
            case INV_SWAP -> {
                if (!(mc.currentScreen instanceof InventoryScreen)) { mode = Mode.BUILD; return; }
                mc.interactionManager.clickSlot(p.playerScreenHandler.syncId, swapFrom, swapTo, SlotActionType.SWAP, p);
                mode = Mode.INV_CLOSE;
                cooldown = 4 + rng.nextInt(10);
            }
            case INV_CLOSE -> {
                p.closeHandledScreen();
                p.getInventory().setSelectedSlot(swapTo);
                mode = Mode.BUILD;
                cooldown = 3 + rng.nextInt(6);
            }
            case CH_WALK -> chestWalk(mc);
            case CH_AIM -> chestAim(mc);
            case CH_WAIT -> {
                if (p.currentScreenHandler != p.playerScreenHandler) { mode = Mode.CH_TAKE; cooldown = 3 + rng.nextInt(8); }
                else if (++modeTicks > 30) { deadChests.add(chest); mode = Mode.BUILD; }
            }
            case CH_TAKE -> chestTake(mc);
            case CH_CLOSE -> {
                p.closeHandledScreen();
                if (took > 0) triedChests.clear(); else triedChests.add(chest);
                took = 0;
                mode = Mode.BUILD;
                cooldown = 6 + rng.nextInt(10);
            }
        }
    }

    // ------------------------------------------------------------ build loop
    private void build(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (mc.currentScreen != null) return;

        if (cur == null || !stillValid(mc, cur)) { cur = pickTarget(mc); walkTicks = 0; }

        if (cur == null) {
            if (cleanup.get() && !scaffolds.isEmpty()) { removeScaffold(mc); return; }
            finish(mc);
            return;
        }

        if (cur.stand() != null && !atStand(p, cur.stand())) {
            if (++walkTicks > 160) { fail(cur.place()); cur = null; return; }
            walkToward(mc, cur.stand());
            return;
        }

        Item item = cur.state().getBlock().asItem();
        if (!ensureItem(mc, item)) return;

        Vec3d eye = p.getEyePos();
        if (eye.distanceTo(cur.hit()) > reach.get() + 0.01 || !canSee(mc, eye, cur.support(), cur.hit())) {
            bump(cur.place()); cur = null; return;
        }
        if (!turnToward(mc, cur.hit())) return;

        // final check with the rotation we really have now
        if (!cur.scaffold() && !orientationOk(mc, cur.state(), cur.support(), cur.face(), cur.hit(), eye, false)) {
            bump(cur.place()); cur = null; return;
        }

        boolean sneak = interactive(mc, cur.support());
        if (sneak && !p.isSneaking()) {
            mc.options.sneakKey.setPressed(true);
            pressedSneak = true;
            cooldown = 1 + rng.nextInt(2);
            return;
        }

        ActionResult r = mc.interactionManager.interactBlock(p, Hand.MAIN_HAND,
                new BlockHitResult(cur.hit(), cur.face(), cur.support(), false));
        if (pressedSneak) { mc.options.sneakKey.setPressed(false); pressedSneak = false; }

        attempts.merge(cur.place(), 1, Integer::sum);
        if (attempts.get(cur.place()) > 5) fail(cur.place());
        if (r.isAccepted()) {
            p.swingHand(Hand.MAIN_HAND);
            if (cur.scaffold()) scaffolds.put(cur.place(), ticks); else placed++;
        }
        cur = null;
        cooldown = Math.max(2, nextDelay());
    }

    private int nextDelay() {
        tempo = MathHelper.clamp(tempo + (1f - tempo) * 0.08f + (float) rng.nextGaussian() * 0.06f, 0.75f, 1.45f);
        float fatigue = Math.min(0.3f, placed / 1500f);
        double d = delay.get() * tempo * (1 + fatigue) * Math.exp(rng.nextGaussian() * 0.28);
        int t = Math.max(1, (int) Math.round(d));
        float roll = rng.nextFloat() * 100f;
        if (roll < pauseChance.get()) { t += 6 + rng.nextInt(18); glance = glancePoint(); }
        else if (roll > 99f) { t += 60 + rng.nextInt(100); glance = glancePoint(); }
        return t;
    }

    private Vec3d glancePoint() {
        ClientPlayerEntity p = MinecraftClient.getInstance().player;
        float yaw = p.getYaw() + (float) rng.nextGaussian() * 12f;
        float pitch = MathHelper.clamp(p.getPitch() + (float) rng.nextGaussian() * 8f, -80f, 80f);
        return p.getEyePos().add(Vec3d.fromPolar(pitch, yaw).multiply(6));
    }

    private void bump(BlockPos pos) {
        if (attempts.merge(pos, 1, Integer::sum) > 5) fail(pos);
    }

    private void fail(BlockPos pos) { failed.add(pos); attempts.remove(pos); }

    private void finish(MinecraftClient mc) {
        int left = 0;
        Set<String> missing = new LinkedHashSet<>();
        for (var en : plan.entrySet()) {
            if (!needsBlock(mc, en.getKey(), en.getValue())) continue;
            left++;
            Item it = en.getValue().getBlock().asItem();
            if (unavailable.contains(it)) missing.add(it.getName().getString());
        }
        chat(mc, left == 0 ? "Build finished (" + placed + " blocks placed)"
                : "Stopped with " + left + " blocks left" + (missing.isEmpty() ? "" : "; out of: " + String.join(", ", missing)));
        requestDisable();
    }

    // ------------------------------------------------------------ world helpers
    private boolean needsBlock(MinecraftClient mc, BlockPos pos, BlockState want) {
        BlockState now = mc.world.getBlockState(pos);
        return now.getBlock() != want.getBlock() && now.isReplaceable();
    }

    private boolean solid(MinecraftClient mc, BlockPos pos) {
        BlockState s = mc.world.getBlockState(pos);
        return !s.isAir() && !s.isReplaceable() && s.getFluidState().isEmpty();
    }

    private boolean free(MinecraftClient mc, BlockPos pos) {
        BlockState s = mc.world.getBlockState(pos);
        return s.getCollisionShape(mc.world, pos).isEmpty() && s.getFluidState().isEmpty();
    }

    private boolean stillValid(MinecraftClient mc, Target t) {
        return mc.world.getBlockState(t.place()).isReplaceable() && solid(mc, t.support());
    }

    private boolean canSee(MinecraftClient mc, Vec3d eye, BlockPos support, Vec3d hit) {
        Vec3d dir = hit.subtract(eye).normalize();
        var res = mc.world.raycast(new RaycastContext(eye, hit.add(dir.multiply(0.05)),
                RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, mc.player));
        return res.getType() == HitResult.Type.BLOCK && res.getBlockPos().equals(support);
    }

    private boolean interactive(MinecraftClient mc, BlockPos support) {
        Block b = mc.world.getBlockState(support).getBlock();
        return mc.world.getBlockEntity(support) != null || b instanceof DoorBlock || b instanceof TrapdoorBlock
                || b instanceof FenceGateBlock || b instanceof ButtonBlock || b instanceof LeverBlock
                || b instanceof CraftingTableBlock || b instanceof AnvilBlock || b instanceof NoteBlock
                || b instanceof BedBlock;
    }

    // ------------------------------------------------------------ orientation
    private static boolean relevant(BlockState s, Property<?> pr) {
        String n = pr.getName();
        if (n.equals("type")) return s.getBlock() instanceof SlabBlock;
        return ORIENT.contains(n);
    }

    private static boolean sameState(BlockState got, BlockState want) {
        for (Property<?> pr : want.getProperties()) {
            if (!relevant(want, pr)) continue;
            if (!got.contains(pr) || !got.get(pr).equals(want.get(pr))) return false;
        }
        return true;
    }

    /** Would clicking here with this camera produce exactly the schematic's state? */
    private boolean orientationOk(MinecraftClient mc, BlockState want, BlockPos support, Direction face,
                                  Vec3d hit, Vec3d eye, boolean hypothetical) {
        boolean any = false;
        for (Property<?> pr : want.getProperties()) if (relevant(want, pr)) { any = true; break; }
        if (!any) return true;

        ClientPlayerEntity p = mc.player;
        float oy = p.getYaw(), op = p.getPitch();
        ItemStack stack = new ItemStack(want.getBlock().asItem());
        BlockHitResult bhr = new BlockHitResult(hit, face, support, false);
        float[] a = anglesTo(eye, hit);
        float[] dys = hypothetical ? new float[]{0, -7, 7} : new float[]{0};
        float[] dps = hypothetical ? new float[]{0, -6, 6} : new float[]{0};
        try {
            for (float dy : dys) for (float dp : dps) {
                if (hypothetical) { p.setYaw(a[0] + dy); p.setPitch(MathHelper.clamp(a[1] + dp, -90f, 90f)); }
                BlockState got = want.getBlock().getPlacementState(new ItemPlacementContext(p, Hand.MAIN_HAND, stack, bhr));
                if (got == null || !sameState(got, want)) return false;
            }
            return true;
        } finally {
            p.setYaw(oy);
            p.setPitch(op);
        }
    }

    // ------------------------------------------------------------ target selection
    private Target pickTarget(MinecraftClient mc) {
        Vec3d eye = mc.player.getEyePos();
        double r = reach.get();

        List<BlockPos> open = new ArrayList<>();
        for (var en : plan.entrySet()) {
            BlockPos b = en.getKey();
            if (failed.contains(b)) continue;
            if (!needsBlock(mc, b, en.getValue())) { attempts.remove(b); continue; }
            if (unavailable.contains(en.getValue().getBlock().asItem())) continue;
            open.add(b);
        }
        if (open.isEmpty()) return null;
        open.sort(Comparator.<BlockPos>comparingInt(BlockPos::getY)
                .thenComparingDouble(b -> b.getSquaredDistance(eye.x, eye.y, eye.z)));

        int checked = 0;
        for (BlockPos pos : open) {
            if (++checked > 80) break;
            Target t = placementFor(mc, pos, plan.get(pos), eye, r, false);
            if (t != null) return t;
        }
        if (walk.get()) {
            Target t = viaWalking(mc, open, r);
            if (t != null) return t;
        }
        return bridge(mc, open, eye, r);
    }

    private Target placementFor(MinecraftClient mc, BlockPos pos, BlockState state, Vec3d eye, double r, boolean scaffold) {
        List<Direction> dirs = new ArrayList<>(Arrays.asList(Direction.values()));
        Collections.shuffle(dirs, rng);
        if (rng.nextFloat() < 0.6f) { dirs.remove(Direction.DOWN); dirs.add(0, Direction.DOWN); } // people prefer the floor
        for (Direction d : dirs) {
            BlockPos support = pos.offset(d);
            if (!solid(mc, support)) continue;
            Direction face = d.getOpposite();
            for (int k = 0; k < (scaffold ? 2 : 6); k++) {
                Vec3d hit = sampleHit(support, face);
                if (eye.distanceTo(hit) > r) continue;
                if (!canSee(mc, eye, support, hit)) continue;
                if (!scaffold && !orientationOk(mc, state, support, face, hit, eye, true)) continue;
                return new Target(pos.toImmutable(), support, face, hit, state, scaffold, null);
            }
        }
        return null;
    }

    private Vec3d sampleHit(BlockPos support, Direction face) {
        Vec3d c = Vec3d.ofCenter(support).add(face.getOffsetX() * 0.5, face.getOffsetY() * 0.5, face.getOffsetZ() * 0.5);
        double u = tri(), v = tri();
        return switch (face.getAxis()) {
            case X -> c.add(0, u, v);
            case Y -> c.add(u, 0, v);
            case Z -> c.add(u, v, 0);
        };
    }

    private double tri() { return (rng.nextDouble() + rng.nextDouble() - 1.0) * 0.38; }

    // ---- walking to a better standing spot
    private Target viaWalking(MinecraftClient mc, List<BlockPos> open, double r) {
        ClientPlayerEntity p = mc.player;
        BlockPos base = p.getBlockPos();
        List<BlockPos> stands = new ArrayList<>();
        for (BlockPos f : BlockPos.iterate(base.add(-6, -3, -6), base.add(6, 3, 6))) {
            if (solid(mc, f.down()) && free(mc, f) && free(mc, f.up())) stands.add(f.toImmutable());
        }
        stands.sort(Comparator.comparingDouble(s -> s.getSquaredDistance(p.getX(), p.getY(), p.getZ())));

        int goals = Math.min(4, open.size());
        for (int g = 0; g < goals; g++) {
            BlockPos goal = open.get(g);
            BlockState st = plan.get(goal);
            int tested = 0;
            for (BlockPos s : stands) {
                if (s.equals(goal) || s.up().equals(goal)) continue;
                Vec3d eye = new Vec3d(s.getX() + 0.5, s.getY() + 1.62, s.getZ() + 0.5);
                if (eye.distanceTo(Vec3d.ofCenter(goal)) > r + 0.9) continue;
                if (++tested > 40) break;
                Vec3d spot = Vec3d.ofBottomCenter(s);
                if (!walkable(mc, p.getPos(), spot)) continue;
                Target t = placementFor(mc, goal, st, eye, r, false);
                if (t != null) return new Target(t.place(), t.support(), t.face(), t.hit(), t.state(), false, spot);
            }
        }
        return null;
    }

    private boolean walkable(MinecraftClient mc, Vec3d a, Vec3d b) {
        if (Math.abs(a.y - b.y) > 1.2) return false;
        int n = (int) Math.ceil(a.distanceTo(b) / 0.4);
        for (int i = 1; i <= n; i++) {
            Vec3d s = a.lerp(b, i / (double) n);
            BlockPos f = BlockPos.ofFloored(s.x, s.y + 0.01, s.z);
            if (!free(mc, f) || !free(mc, f.up())) return false;
            if (!solid(mc, f.down()) && !solid(mc, f.down(2))) return false;
        }
        return true;
    }

    private boolean atStand(ClientPlayerEntity p, Vec3d stand) {
        return Math.hypot(p.getX() - stand.x, p.getZ() - stand.z) < 0.6 && Math.abs(p.getY() - stand.y) < 1.0;
    }

    // ---- scaffolding
    private Item scaffoldItem(MinecraftClient mc) {
        Item configured = Registries.ITEM.get(Identifier.tryParse(scaffoldItemSetting.get()));
        if (configured instanceof BlockItem && !unavailable.contains(configured)) {
            if (countInv(mc, configured) > 0) return configured;
        }
        Map<Item, Integer> needs = needs(mc);
        for (Item it : FALLBACK) {
            if (countInv(mc, it) > 0 && needs.getOrDefault(it, 0) == 0) return it;
        }
        if (configured instanceof BlockItem && !unavailable.contains(configured)) return configured; // fetch from a chest
        return null;
    }

    private Target bridge(MinecraftClient mc, List<BlockPos> open, Vec3d eye, double r) {
        if (scaffolds.size() >= maxScaffold.get()) return null;
        Item sc = scaffoldItem(mc);
        if (!(sc instanceof BlockItem bi)) return null;
        BlockState ss = bi.getBlock().getDefaultState();

        BlockPos goal = open.get(0);
        BlockPos feet = mc.player.getBlockPos();
        Target best = null;
        double bestD = goal.getSquaredDistance(eye.x, eye.y, eye.z);
        int R = (int) Math.ceil(r);
        BlockPos base = BlockPos.ofFloored(eye);
        for (BlockPos c : BlockPos.iterate(base.add(-R, -R, -R), base.add(R, R, R))) {
            if (plan.containsKey(c) || !mc.world.getBlockState(c).isReplaceable()) continue;
            if (c.equals(feet) || c.equals(feet.up())) continue;
            double d = c.getSquaredDistance(goal);
            if (d >= bestD) continue;
            Target t = placementFor(mc, c.toImmutable(), ss, eye, r, true);
            if (t != null) { best = t; bestD = d; }
        }
        return best;
    }

    private void removeScaffold(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        scaffolds.entrySet().removeIf(e -> mc.world.getBlockState(e.getKey()).isAir() && ticks - e.getValue() > 30);
        if (scaffolds.isEmpty()) return;

        Vec3d eye = p.getEyePos();
        BlockPos near = null;
        double bd = Double.MAX_VALUE;
        for (BlockPos b : scaffolds.keySet()) {
            double d = Vec3d.ofCenter(b).distanceTo(eye);
            if (d < bd) { bd = d; near = b; }
        }
        if (near == null) return;
        if (!near.equals(breakPos)) {
            breakPos = near;
            breakAim = Vec3d.ofCenter(near).add(tri() * 0.5, tri() * 0.5, tri() * 0.5);
            walkTicks = 0;
        }
        if (bd > reach.get() - 0.3) {
            if (!walk.get() || ++walkTicks > 200) { scaffolds.remove(near); breakPos = null; return; }
            walkToward(mc, Vec3d.ofCenter(near));
            return;
        }

        var inv = p.getInventory();
        BlockState bs = mc.world.getBlockState(near);
        int sel = inv.getSelectedSlot(), best = sel;
        float bestSpeed = inv.getStack(sel).getMiningSpeedMultiplier(bs);
        for (int i = 0; i < 9; i++) {
            float sp = inv.getStack(i).getMiningSpeedMultiplier(bs);
            if (sp > bestSpeed + 0.01f) { bestSpeed = sp; best = i; }
        }
        if (best != sel) { inv.setSelectedSlot(best); cooldown = 1 + rng.nextInt(3); return; }

        if (!turnToward(mc, breakAim)) return;
        Direction side = Direction.getFacing(eye.x - breakAim.x, eye.y - breakAim.y, eye.z - breakAim.z);
        mc.interactionManager.updateBlockBreakingProgress(near, side);
        p.swingHand(Hand.MAIN_HAND);
    }

    // ------------------------------------------------------------ materials
    private int countInv(MinecraftClient mc, Item item) {
        var inv = mc.player.getInventory();
        int n = 0;
        for (int i = 0; i < 36; i++) if (inv.getStack(i).isOf(item)) n += inv.getStack(i).getCount();
        return n;
    }

    private Map<Item, Integer> needs(MinecraftClient mc) {
        if (ticks - needTick > 40) {
            Map<Item, Integer> m = new HashMap<>();
            for (var en : plan.entrySet()) {
                if (failed.contains(en.getKey()) || !needsBlock(mc, en.getKey(), en.getValue())) continue;
                m.merge(en.getValue().getBlock().asItem(), 1, Integer::sum);
            }
            needCache = m;
            needTick = ticks;
        }
        return needCache;
    }

    /** Gets the item into the selected hotbar slot, or starts the task that will. */
    private boolean ensureItem(MinecraftClient mc, Item item) {
        ClientPlayerEntity p = mc.player;
        var inv = p.getInventory();
        if (inv.getStack(inv.getSelectedSlot()).isOf(item)) return true;
        for (int i = 0; i < 9; i++) {
            if (inv.getStack(i).isOf(item)) { inv.setSelectedSlot(i); cooldown = 1 + rng.nextInt(3); return false; }
        }
        for (int i = 9; i < 36; i++) {
            if (inv.getStack(i).isOf(item)) {
                swapFrom = i;
                swapTo = hotbarTarget(mc);
                mode = Mode.INV_OPEN;
                cooldown = 2 + rng.nextInt(6);
                return false;
            }
        }
        if (p.isCreative()) { // creative: take it from the creative menu
            swapTo = hotbarTarget(mc);
            mc.interactionManager.clickCreativeStack(new ItemStack(item, item.getMaxCount()), 36 + swapTo);
            inv.setSelectedSlot(swapTo);
            cooldown = 3 + rng.nextInt(6);
            return false;
        }
        obtain(mc, item);
        return false;
    }

    private int hotbarTarget(MinecraftClient mc) {
        var inv = mc.player.getInventory();
        Map<Item, Integer> needs = needs(mc);
        for (int i = 0; i < 9; i++) if (inv.getStack(i).isEmpty()) return i;
        for (int i = 0; i < 9; i++) {
            Item it = inv.getStack(i).getItem();
            if (needs.getOrDefault(it, 0) == 0 && !(it instanceof BlockItem && it == scaffoldItem(mc))) return i;
        }
        return inv.getSelectedSlot();
    }

    private void obtain(MinecraftClient mc, Item item) {
        BlockPos best = null;
        if (useChests.get()) {
            double bd = Double.MAX_VALUE;
            for (BlockPos c : linkedChests(mc)) {
                if (triedChests.contains(c) || deadChests.contains(c)) continue;
                double d = c.getSquaredDistance(mc.player.getPos());
                if (d < bd) { bd = d; best = c; }
            }
        }
        if (best == null) {
            unavailable.add(item);
            triedChests.clear();
            chat(mc, "Out of " + item.getName().getString());
            cur = null;
            return;
        }
        chest = best;
        chestHit = null;
        modeTicks = 0;
        mode = Mode.CH_WALK;
        cooldown = 4 + rng.nextInt(8);
    }

    private Map<Item, Integer> wanted(MinecraftClient mc) {
        Map<Item, Integer> w = new HashMap<>();
        for (var en : needs(mc).entrySet()) {
            if (unavailable.contains(en.getKey())) continue;
            int missing = en.getValue() - countInv(mc, en.getKey());
            if (missing > 0) w.put(en.getKey(), missing);
        }
        Item sc = scaffoldItem(mc);
        if (sc != null) {
            int missing = 16 - countInv(mc, sc);
            if (missing > 0) w.merge(sc, missing, Math::max);
        }
        return w;
    }

    private boolean hasRoom(ClientPlayerEntity p) {
        for (int i = 0; i < 36; i++) if (p.getInventory().getStack(i).isEmpty()) return true;
        return false;
    }

    // ---- chest trip
    private boolean chestVisible(MinecraftClient mc) {
        Vec3d eye = mc.player.getEyePos();
        var res = mc.world.raycast(new RaycastContext(eye, Vec3d.ofCenter(chest),
                RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, mc.player));
        return res.getType() == HitResult.Type.BLOCK && res.getBlockPos().equals(chest);
    }

    private void chestWalk(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (++modeTicks > 240) { deadChests.add(chest); mode = Mode.BUILD; return; }
        double d = p.getEyePos().distanceTo(Vec3d.ofCenter(chest));
        if (d <= Math.min(reach.get(), 3.6) && chestVisible(mc)) { mode = Mode.CH_AIM; modeTicks = 0; return; }
        walkToward(mc, Vec3d.ofCenter(chest));
    }

    private void chestAim(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (!chestVisible(mc)) { mode = Mode.CH_WALK; return; }
        Vec3d eye = p.getEyePos();
        if (chestHit == null) {
            Vec3d c = Vec3d.ofCenter(chest);
            chestFace = Direction.getFacing(eye.x - c.x, eye.y - c.y, eye.z - c.z);
            chestHit = sampleHit(chest, chestFace);
        }
        if (!turnToward(mc, chestHit)) { if (++modeTicks > 60) { deadChests.add(chest); mode = Mode.BUILD; } return; }
        mc.interactionManager.interactBlock(p, Hand.MAIN_HAND, new BlockHitResult(chestHit, chestFace, chest, false));
        p.swingHand(Hand.MAIN_HAND);
        modeTicks = 0;
        mode = Mode.CH_WAIT;
        cooldown = 1;
    }

    private void chestTake(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        ScreenHandler h = p.currentScreenHandler;
        if (h == p.playerScreenHandler) { mode = Mode.BUILD; return; }
        Map<Item, Integer> want = wanted(mc);
        Slot pick = null;
        for (Slot s : h.slots) {
            if (s.inventory instanceof PlayerInventory) continue;
            ItemStack st = s.getStack();
            if (!st.isEmpty() && want.getOrDefault(st.getItem(), 0) > 0) { pick = s; break; }
        }
        if (pick == null || !hasRoom(p)) { mode = Mode.CH_CLOSE; cooldown = 3 + rng.nextInt(8); return; }
        mc.interactionManager.clickSlot(h.syncId, pick.id, 0, SlotActionType.QUICK_MOVE, p);
        took++;
        needTick = -999; // counts changed
        cooldown = 2 + rng.nextInt(4);
    }

    // ------------------------------------------------------------ movement
    private void walkToward(MinecraftClient mc, Vec3d t) {
        ClientPlayerEntity p = mc.player;
        walkedThisTick = true;
        turnToward(mc, new Vec3d(t.x, p.getEyeY(), t.z));
        double dist = Math.hypot(p.getX() - t.x, p.getZ() - t.z);
        boolean go = Math.abs(lastYawErr) < 35f && dist > 0.5;
        mc.options.forwardKey.setPressed(go);
        pressedFwd = true;
        mc.options.jumpKey.setPressed(go && p.horizontalCollision && p.isOnGround());
        pressedJump = true;
    }

    private void releaseWalk(MinecraftClient mc) {
        if (pressedFwd) { mc.options.forwardKey.setPressed(false); pressedFwd = false; }
        if (pressedJump) { mc.options.jumpKey.setPressed(false); pressedJump = false; }
    }

    private void releaseInput(MinecraftClient mc) {
        releaseWalk(mc);
        if (pressedSneak) { mc.options.sneakKey.setPressed(false); pressedSneak = false; }
    }

    // ------------------------------------------------------------ camera
    private float[] anglesTo(Vec3d from, Vec3d to) {
        Vec3d d = to.subtract(from);
        float yaw = (float) (MathHelper.atan2(d.z, d.x) * 180.0 / Math.PI) - 90f;
        float pitch = (float) -(MathHelper.atan2(d.y, Math.sqrt(d.x * d.x + d.z * d.z)) * 180.0 / Math.PI);
        return new float[]{yaw, pitch};
    }

    private double gcd(MinecraftClient mc) {
        double f = mc.options.getMouseSensitivity().getValue() * 0.6 + 0.2;
        return f * f * f * 8.0 * 0.15; // one "mouse count" in degrees
    }

    private boolean applyAccum(ClientPlayerEntity p, double g) {
        int sy = (int) Math.round(ay / g), sp = (int) Math.round(ap / g);
        if (sy != 0) { p.setYaw(p.getYaw() + (float) (sy * g)); ay -= (float) (sy * g); }
        if (sp != 0) { p.setPitch(MathHelper.clamp(p.getPitch() + (float) (sp * g), -90f, 90f)); ap -= (float) (sp * g); }
        return sy != 0 || sp != 0;
    }

    /**
     * Spring-damper aiming: accelerates, can slightly overshoot, settles, in whole mouse counts.
     * Returns true once on target and still for a tick (so the server has the same rotation).
     */
    private boolean turnToward(MinecraftClient mc, Vec3d point) {
        ClientPlayerEntity p = mc.player;
        float[] a = anglesTo(p.getEyePos(), point);
        float dy = MathHelper.wrapDegrees(a[0] - p.getYaw());
        float dp = a[1] - p.getPitch();
        lastYawErr = dy;
        float err = (float) Math.hypot(dy, dp);
        double g = gcd(mc);

        if (err <= Math.max(1.2, g * 2) && Math.hypot(vy, vp) < 0.7) {
            vy = vp = 0;
            inMotion = false;
            if (movedLast) { movedLast = false; return false; }
            return true;
        }
        if (!inMotion) {
            inMotion = true;
            stiff = 0.18f + rng.nextFloat() * 0.10f;
            damp = 2f * (float) Math.sqrt(stiff) * (0.7f + rng.nextFloat() * 0.25f);
        }
        float max = turnSpeed.get();
        vy += dy * stiff - vy * damp + (float) rng.nextGaussian() * 0.04f;
        vp += dp * stiff * 0.9f - vp * damp + (float) rng.nextGaussian() * 0.03f;
        vy = MathHelper.clamp(vy, -max, max);
        vp = MathHelper.clamp(vp, -max * 0.6f, max * 0.6f);
        ay += vy;
        ap += vp;
        movedLast = applyAccum(p, g);
        return false;
    }

    /** Tiny involuntary hand movement while waiting. */
    private void drift(MinecraftClient mc) {
        ay += (float) rng.nextGaussian() * 0.05f;
        ap += (float) rng.nextGaussian() * 0.035f;
        applyAccum(mc.player, gcd(mc));
    }

    private void showProgress(MinecraftClient mc) {
        if (mc.player == null || plan.isEmpty()) return;
        int remaining = 0;
        Map<Item, Integer> missing = new LinkedHashMap<>();
        for (var en : plan.entrySet()) {
            if (needsBlock(mc, en.getKey(), en.getValue()) && !failed.contains(en.getKey())) {
                remaining++;
                Item item = en.getValue().getBlock().asItem();
                int inInv = countInv(mc, item);
                if (inInv == 0) missing.merge(item, 1, Integer::sum);
            }
        }
        int done = Math.max(0, plan.size() - remaining);
        String mats = missing.isEmpty() ? "materials OK" : "missing " +
                missing.entrySet().stream().limit(3).map(e -> e.getKey().getName().getString() +
                (e.getValue() > 1 ? " x" + e.getValue() : "")).reduce((a,b) -> a + ", " + b).orElse("");
        mc.player.sendMessage(Text.literal("[Builder] " + done + "/" + plan.size() +
                " | left " + remaining + " | " + mats), true);
    }

    private void chat(MinecraftClient mc, String s) {
        if (mc.player != null) mc.player.sendMessage(Text.literal("[Schematic] " + s), false);
    }
}

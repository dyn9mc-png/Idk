package net.example.schem;

import net.anubis.client.addon.AnubisAddon;
import net.anubis.client.module.ModuleRegistry;

public final class SchemAddon extends AnubisAddon {
    @Override public void onInitialize() { ModuleRegistry.add(new SchematicBuilderModule()); }
    @Override public String getPackage() { return "net.example.schem"; }
}
